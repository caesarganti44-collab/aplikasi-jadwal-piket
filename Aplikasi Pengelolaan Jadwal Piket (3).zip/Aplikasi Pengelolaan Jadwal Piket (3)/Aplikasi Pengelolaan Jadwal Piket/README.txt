Nama: Caesar Ganti
NIM: 2404411629
Program Studi: Informatika
Fakultas: Teknik Komputer
Universitas: Universitas Cokroaminoto Palopo

Aplikasi ini merupakan project Ujian Akhir Semester (UAS) mata kuliah Aplikasi Mobile yang dibuat menggunakan Java Swing dan SQLite sebagai database lokal. Aplikasi ini digunakan untuk mengelola jadwal piket, mulai dari input data, pengeditan, penghapusan, pencarian, hingga penyimpanan permanen di database.

Aplikasi ini bertujuan untuk mempermudah pengelolaan jadwal piket dengan fitur CRUD (Create, Read, Update, Delete) serta pencarian data secara cepat. Aplikasi ini dibuat sebagai pemenuhan tugas UAS.

Teknologi yang Digunakan:
Java (JDK 8+)
Java Swing (GUI)
SQLite (Database lokal)
JDBC SQLite Driver
IntelliJ IDEA