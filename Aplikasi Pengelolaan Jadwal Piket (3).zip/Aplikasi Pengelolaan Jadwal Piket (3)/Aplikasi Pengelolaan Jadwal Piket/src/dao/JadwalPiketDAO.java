package dao;

import model.JadwalPiket;
import util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JadwalPiketDAO {

    public JadwalPiketDAO() {
        createTable();
    }

    private void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS jadwal_piket (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nama TEXT," +
                "hari TEXT," +
                "tanggal TEXT," +
                "tugas TEXT" +
                ")";

        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insert(JadwalPiket jp) {
        String sql = "INSERT INTO jadwal_piket(nama, hari, tanggal, tugas) VALUES(?,?,?,?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, jp.getNama());
            ps.setString(2, jp.getHari());
            ps.setString(3, jp.getTanggal());
            ps.setString(4, jp.getTugas());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(JadwalPiket jp) {
        String sql = "UPDATE jadwal_piket SET nama=?, hari=?, tanggal=?, tugas=? WHERE id=?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, jp.getNama());
            ps.setString(2, jp.getHari());
            ps.setString(3, jp.getTanggal());
            ps.setString(4, jp.getTugas());
            ps.setInt(5, jp.getId());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(int id) {
        String sql = "DELETE FROM jadwal_piket WHERE id=?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<JadwalPiket> getAll() {
        List<JadwalPiket> list = new ArrayList<>();
        String sql = "SELECT * FROM jadwal_piket";

        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                JadwalPiket jp = new JadwalPiket(
                        rs.getInt("id"),
                        rs.getString("nama"),
                        rs.getString("hari"),
                        rs.getString("tanggal"),
                        rs.getString("tugas")
                );
                list.add(jp);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<JadwalPiket> search(String keyword) {
        List<JadwalPiket> list = new ArrayList<>();
        String sql = "SELECT * FROM jadwal_piket WHERE nama LIKE ? OR hari LIKE ? OR tugas LIKE ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String key = "%" + keyword + "%";
            ps.setString(1, key);
            ps.setString(2, key);
            ps.setString(3, key);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                JadwalPiket jp = new JadwalPiket(
                        rs.getInt("id"),
                        rs.getString("nama"),
                        rs.getString("hari"),
                        rs.getString("tanggal"),
                        rs.getString("tugas")
                );
                list.add(jp);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
