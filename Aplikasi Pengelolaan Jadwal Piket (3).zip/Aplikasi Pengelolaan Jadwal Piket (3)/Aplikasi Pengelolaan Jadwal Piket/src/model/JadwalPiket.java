package model;

public class JadwalPiket {
    private int id;
    private String nama;
    private String hari;
    private String tanggal;
    private String tugas;

    public JadwalPiket(int id, String nama, String hari, String tanggal, String tugas) {
        this.id = id;
        this.nama = nama;
        this.hari = hari;
        this.tanggal = tanggal;
        this.tugas = tugas;
    }

    public JadwalPiket(String nama, String hari, String tanggal, String tugas) {
        this.nama = nama;
        this.hari = hari;
        this.tanggal = tanggal;
        this.tugas = tugas;
    }

    public int getId() { return id; }
    public String getNama() { return nama; }
    public String getHari() { return hari; }
    public String getTanggal() { return tanggal; }
    public String getTugas() { return tugas; }

    public void setId(int id) { this.id = id; }
    public void setNama(String nama) { this.nama = nama; }
    public void setHari(String hari) { this.hari = hari; }
    public void setTanggal(String tanggal) { this.tanggal = tanggal; }
    public void setTugas(String tugas) { this.tugas = tugas; }
}
