package ui;

import dao.JadwalPiketDAO;
import model.JadwalPiket;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MainFrame extends JFrame {

    JTextField txtNama, txtTanggal, txtTugas, txtSearch;
    JComboBox<String> cmbHari;
    JButton btnTambah, btnUbah, btnHapus, btnReset;

    JTable table;
    DefaultTableModel tableModel;

    JadwalPiketDAO dao;
    int selectedId = -1;

    public MainFrame() {
        setTitle("Aplikasi Pengelolaan Jadwal Piket");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        dao = new JadwalPiketDAO();

        initComponents();
        loadData();

        setVisible(true);
    }

    private void initComponents() {
        JPanel panelUtama = new JPanel(new BorderLayout(10, 10));

        // ===== FORM =====
        JPanel panelForm = new JPanel(new GridLayout(4, 2, 10, 10));
        panelForm.setBorder(BorderFactory.createTitledBorder("Form Jadwal Piket"));

        JLabel lblNama = new JLabel("Nama:");
        txtNama = new JTextField();

        JLabel lblHari = new JLabel("Hari:");
        String[] hari = {"Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"};
        cmbHari = new JComboBox<>(hari);

        JLabel lblTanggal = new JLabel("Tanggal:");
        txtTanggal = new JTextField();

        JLabel lblTugas = new JLabel("Tugas:");
        txtTugas = new JTextField();

        panelForm.add(lblNama);
        panelForm.add(txtNama);
        panelForm.add(lblHari);
        panelForm.add(cmbHari);
        panelForm.add(lblTanggal);
        panelForm.add(txtTanggal);
        panelForm.add(lblTugas);
        panelForm.add(txtTugas);

        // ===== BUTTON =====
        JPanel panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        btnTambah = new JButton("Tambah");
        btnUbah = new JButton("Ubah");
        btnHapus = new JButton("Hapus");
        btnReset = new JButton("Reset");

        panelButton.add(btnTambah);
        panelButton.add(btnUbah);
        panelButton.add(btnHapus);
        panelButton.add(btnReset);

        // ===== SEARCH =====
        JPanel panelSearch = new JPanel(new BorderLayout());
        panelSearch.setBorder(BorderFactory.createTitledBorder("Cari Data"));
        txtSearch = new JTextField();
        panelSearch.add(txtSearch, BorderLayout.CENTER);

        // ===== TABLE =====
        tableModel = new DefaultTableModel(new Object[]{"ID", "Nama", "Hari", "Tanggal", "Tugas"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Data Jadwal Piket"));

        // ===== GABUNG =====
        JPanel panelAtas = new JPanel(new BorderLayout());
        panelAtas.add(panelForm, BorderLayout.NORTH);
        panelAtas.add(panelButton, BorderLayout.CENTER);
        panelAtas.add(panelSearch, BorderLayout.SOUTH);

        panelUtama.add(panelAtas, BorderLayout.NORTH);
        panelUtama.add(scrollPane, BorderLayout.CENTER);

        add(panelUtama);

        // ===== EVENT =====
        btnTambah.addActionListener(e -> tambahData());
        btnUbah.addActionListener(e -> ubahData());
        btnHapus.addActionListener(e -> hapusData());
        btnReset.addActionListener(e -> resetForm());

        table.getSelectionModel().addListSelectionListener(e -> isiFormDariTabel());

        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { searchData(); }
            public void removeUpdate(DocumentEvent e) { searchData(); }
            public void changedUpdate(DocumentEvent e) { searchData(); }
        });
    }

    private void tambahData() {
        String nama = txtNama.getText();
        String hari = cmbHari.getSelectedItem().toString();
        String tanggal = txtTanggal.getText();
        String tugas = txtTugas.getText();

        if (nama.isEmpty() || tanggal.isEmpty() || tugas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Harap isi semua field!");
            return;
        }

        JadwalPiket jp = new JadwalPiket(nama, hari, tanggal, tugas);
        dao.insert(jp);

        loadData();
        resetForm();

        JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
    }

    private void isiFormDariTabel() {
        int row = table.getSelectedRow();
        if (row != -1) {
            selectedId = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
            txtNama.setText(tableModel.getValueAt(row, 1).toString());
            cmbHari.setSelectedItem(tableModel.getValueAt(row, 2).toString());
            txtTanggal.setText(tableModel.getValueAt(row, 3).toString());
            txtTugas.setText(tableModel.getValueAt(row, 4).toString());
        }
    }

    private void ubahData() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin diubah!");
            return;
        }

        String nama = txtNama.getText();
        String hari = cmbHari.getSelectedItem().toString();
        String tanggal = txtTanggal.getText();
        String tugas = txtTugas.getText();

        JadwalPiket jp = new JadwalPiket(selectedId, nama, hari, tanggal, tugas);
        dao.update(jp);

        loadData();
        resetForm();

        JOptionPane.showMessageDialog(this, "Data berhasil diubah!");
    }

    private void hapusData() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin dihapus!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dao.delete(selectedId);
            loadData();
            resetForm();
        }
    }

    private void loadData() {
        tableModel.setRowCount(0);

        List<JadwalPiket> list = dao.getAll();
        for (JadwalPiket jp : list) {
            tableModel.addRow(new Object[]{
                    jp.getId(),
                    jp.getNama(),
                    jp.getHari(),
                    jp.getTanggal(),
                    jp.getTugas()
            });
        }
    }

    private void searchData() {
        String keyword = txtSearch.getText();
        List<JadwalPiket> list = dao.search(keyword);

        tableModel.setRowCount(0);
        for (JadwalPiket jp : list) {
            tableModel.addRow(new Object[]{
                    jp.getId(),
                    jp.getNama(),
                    jp.getHari(),
                    jp.getTanggal(),
                    jp.getTugas()
            });
        }
    }

    private void resetForm() {
        txtNama.setText("");
        txtTanggal.setText("");
        txtTugas.setText("");
        cmbHari.setSelectedIndex(0);
        selectedId = -1;
        table.clearSelection();
    }
}
